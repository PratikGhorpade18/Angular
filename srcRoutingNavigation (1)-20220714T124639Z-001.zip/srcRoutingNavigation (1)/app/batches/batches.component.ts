import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batches',
  templateUrl: './batches.component.html'
})
export class BatchesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
